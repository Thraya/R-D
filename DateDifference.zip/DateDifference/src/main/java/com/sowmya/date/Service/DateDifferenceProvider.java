package com.sowmya.date.Service;

import com.sowmya.date.Pojo.MyDate;

public class DateDifferenceProvider {
	@SuppressWarnings("unused")
	private static int FEB=2;
	
	@SuppressWarnings("unused")
	private static int DAYS_IN_LEAP_YEAR= 366;
	@SuppressWarnings("unused")
	private static int DAYS_IN_NON_LEAP_YEAR=365;
	
	public static int DAY_IN_JAN=31;
	public static int DAY_IN_FEB=28;
	public static int DAY_IN_MAR=31;
	public static int DAY_IN_APR=30;
	public static int DAY_IN_MAY=31;
	public static int DAY_IN_JUN=30;
	public static int DAY_IN_JUL=31;
	public static int DAY_IN_AUG=31;
	public static int DAY_IN_SEP=30;
	public static int DAY_IN_OCT=31;
	public static int DAY_IN_NOV=30;
	public static int DAY_IN,DEC=31;
	
	public static int NoOfMonths[] ={ DAY_IN_JAN,
									  DAY_IN_FEB,
									  DAY_IN_MAR,
									  DAY_IN_APR,
									  DAY_IN_MAY,
									  DAY_IN_JUN,
									  DAY_IN_JUL,
									  DAY_IN_AUG,
									  DAY_IN_SEP,
									  DAY_IN_OCT,
									  DAY_IN_NOV,
									  DAY_IN,DEC };
	
	
public static long getDateDifference(MyDate startDate, MyDate endDate) {
	
	//case 1
	if(sameDate(startDate,endDate)&&
	   sameMonth(startDate,endDate)&&
	   sameYear(startDate,endDate)) {
		return 0;
	}
	
	else if(sameMonth(startDate,endDate)&&
			sameYear(startDate,endDate)) {
		return endDate.getDd()-startDate.getDd();
	}
	
	else if(sameYear(startDate,endDate)&&
			!sameMonth(startDate,endDate)) {
		return  remainingDaysInMonth(startDate)+
				daysInInterveningMonth(startDate,endDate)+
				leadingMonth(endDate);
	}
	
	else {
		return remainingDaysInYear(startDate)+
				daysInInterveningYear(endDate)+
				leadingYear(endDate);
	}
}
	
	//case 2
		/*if(endDate.getDd()!=startDate.getDd()&&endDate.getMm()==startDate.getMm()&& endDate.getYyyy()==startDate.getYyyy()) {
			NoOfDays = endDate.getDd() - startDate.getDd();
		}
		
		//case 3
		if(endDate.getDd()!=startDate.getDd() && endDate.getMm()!=startDate.getMm() && endDate.getYyyy()==startDate.getYyyy()) {
			NoOfDays= ((endDate.getMm()-startDate.getMm()));
		}*/



private static int leadingYear(MyDate endDate) {
	return endDate.getDd();
}


private static int daysInInterveningYear(MyDate endDate) {
	// TODO Auto-generated method stub
	return 0;
}


private static int remainingDaysInYear(MyDate startDate) {
	
	return 0;
}


private static int daysInInterveningMonth(MyDate startDate, MyDate endDate) {
	int NoOfDays=0;
	for(int month=startDate.getMm();month<endDate.getMm()-1;month++) {
		NoOfDays+=NoOfMonths[month];
	}
	return NoOfDays;
}


private static int leadingMonth(MyDate endDate) {
	return endDate.getDd();
}          

private static int remainingDaysInMonth(MyDate startDate) {
	return (NoOfMonths[startDate.getMm()-1])-startDate.getDd();
}


private static boolean sameYear(MyDate startDate, MyDate endDate) {
	if(endDate.getYyyy()==startDate.getYyyy()) 
		return true;
	else
		return false;
}


private static boolean sameMonth(MyDate startDate, MyDate endDate) {
	if(endDate.getMm()==startDate.getMm()) 
		return true;
	else
		return false;
}

private static boolean sameDate(MyDate startDate, MyDate endDate) {
	if(endDate.getDd()==startDate.getDd()) 
		return true;
	else
		return false;
	}
}
