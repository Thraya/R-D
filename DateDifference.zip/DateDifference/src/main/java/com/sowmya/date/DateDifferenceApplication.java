package com.sowmya.date;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DateDifferenceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DateDifferenceApplication.class, args);
	}
}
