package com.sowmya.date.Test;

import java.util.ArrayList;

import com.sowmya.date.Pojo.MyDate;
import com.sowmya.date.Service.DateDifferenceProvider;

public class DateDifferenceTest {
	
	public static void main(String[] args) {
		
		ArrayList<MyDateTestRecord> testDate = new ArrayList<>(); 
		
		testDate.add(new MyDateTestRecord(new MyDate(06, 04, 2011), new MyDate(06, 04, 2011), 0));
        testDate.add(new MyDateTestRecord(new MyDate(06, 04, 2011), new MyDate(18, 04, 2011), 12));
        testDate.add(new MyDateTestRecord(new MyDate(06, 04, 2011), new MyDate(18, 05, 2011), 42));
        testDate.add(new MyDateTestRecord(new MyDate(06, 04, 2011), new MyDate(18, 06, 2011), 73));
        testDate.add(new MyDateTestRecord(new MyDate(06, 04, 2011), new MyDate(18, 12, 2011), 256));
        testDate.add(new MyDateTestRecord(new MyDate(06, 04, 2011), new MyDate(18, 12, 2012), 622));
        testDate.add(new MyDateTestRecord(new MyDate(06, 04, 2011), new MyDate(18, 12, 2013), 987));
        testDate.add(new MyDateTestRecord(new MyDate(06, 04, 2011), new MyDate(18, 12, 2113), 37511));
        testDate.add(new MyDateTestRecord(new MyDate(06, 04, 2011), new MyDate(18, 12, 2413), 147084));
        testDate.add(new MyDateTestRecord(new MyDate(06, 04, 2011), new MyDate(18, 12, 2813), 293181));
        testDate.add(new MyDateTestRecord(new MyDate(06, 01, 2011), new MyDate(06, 03, 2011), 59));
        testDate.add(new MyDateTestRecord(new MyDate(06, 01, 2012), new MyDate(06, 03, 2012), 60));
        testDate.add(new MyDateTestRecord(new MyDate(06, 02, 2012), new MyDate(06, 03, 2012), 29));
        testDate.add(new MyDateTestRecord(new MyDate(22, 01, 2012), new MyDate(15, 11, 2012), 298));
        testDate.add(new MyDateTestRecord(new MyDate(06, 02, 2012), new MyDate(06, 12, 2012), 304));
	
		for(MyDateTestRecord testCase:testDate) {
			MyDate startDate=testCase.startDate;
			MyDate endDate=testCase.endDate;
			long expectedResult=testCase.expectedResult;
			long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
			if(expectedResult == obtainedResult) {
				System.out.println("Test "+(1+testDate.lastIndexOf(testCase))+" Passed "+obtainedResult
						+"=ObtainedResult "+expectedResult+"=expectedResult");
			}
			else {
				System.err.println("Test "+(1+testDate.lastIndexOf(testCase))+" Failed "+obtainedResult
						+"=ObtainedResult "+expectedResult+"=expectedResult");
		  }
		}
	}

}
