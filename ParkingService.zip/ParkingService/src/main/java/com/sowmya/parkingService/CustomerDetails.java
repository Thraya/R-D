package com.sowmya.parkingService;

public class CustomerDetails {
	String CustomerName;
	String CustomerNumber;
	String Time;
	ParkingId id;
	public ParkingId getId() {
	return id;
	}
	public void setId(ParkingId id) {
	this.id = id;
	}
	@Override
	public String toString() {
	return "CustomerDetails [CustomerName=" + CustomerName + ", CustomerNumber=" + CustomerNumber + ", Time=" + Time + "]";
	}
	public CustomerDetails(String customerName, String customerNumber, String time) {
	super();
	CustomerName = customerName;
	CustomerNumber = customerNumber;
	Time = time;
	}
	public String getCustomerName() {
	return CustomerNumber;
	}
	public void setCustomerName(String customerName) {
	CustomerNumber = customerName;
	}
	public String getCustomerNumber() {
	return CustomerNumber;
	}
	public void setCustomerNumber(String customerNumber) {
	CustomerNumber = customerNumber;
	}
	public String getTime() {
	return Time;
	}
	public void setTime(String time) {
	Time = time;
	}

}
