package com.sowmya.parkingService;

import java.util.Map;

public class Main {
	@SuppressWarnings("rawtypes")
	public static void main(String[] args) {
		Park park=new Park();
		CustomerDetails owner=new CustomerDetails("Sowmya", "9483007255", "1:45");
		park.addCar(new CustomerDetails("Akshatha","8288811768", "11:00"));
		park.addCar(new CustomerDetails("Gagan","1234567891", "11:12"));
		park.addCar(new CustomerDetails("Akash","8288811768", "2:45"));
		park.addCar(new CustomerDetails("Susheel","2233445566", "3:20"));
		park.addCar(new CustomerDetails("Ramya","5678901234", "1:20"));
		park.addCar(new CustomerDetails("Swetha","5567890345", "5:00"));
		park.addCar(new CustomerDetails("Kavya","1234567543", "1:20"));
		park.addCar(new CustomerDetails("Amrutha","98765433678", "2:00"));
		park.addCar(new CustomerDetails("Chethana","1246785467", "3:00"));
		park.addCar(new CustomerDetails("Sandhya","3345768734", "7:00"));
		park.addCar(new CustomerDetails("RamyaShree","35748645768", "9:00"));
		park.addCar(owner);
		park.getAllCars();
		for(Map.Entry e: park.getAllCars() ) {
		System.out.println(e.getKey()+" " + e.getValue());
		}
		System.out.println(park.getCarById(owner.getId()));
		}


}
