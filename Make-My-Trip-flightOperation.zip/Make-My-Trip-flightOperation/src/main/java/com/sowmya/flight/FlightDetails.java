package com.sowmya.flight;

public class FlightDetails {
	String flightName,departure,arrival;
	int flightId,departureTime,totalTime,cost;
	int arrivalTime;
	
	public FlightDetails(int flightId, String flightName, String departure, String arrival, int departureTime,
			int arrivalTime, int totalTime,int cost) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.departure = departure;
		this.arrival = arrival;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.totalTime = totalTime;
		this.cost = cost;
		
	}

	@Override
	public String toString() {
		return "FlightDetails [flightId=" + flightId + ", flightName"+flightName+", departure=" + departure + ", arrival=" + arrival
				+", departureTime=" + departureTime + ", arrivalTime=" + arrivalTime
				+ ", totalTime=" + totalTime + ", cost=" + cost + "]";
	}

	public FlightDetails() {
		// TODO Auto-generated constructor stub
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getDeparture() {
		return departure;
	}

	public void setDeparture(String departure) {
		this.departure = departure;
	}

	public String getArrival() {
		return arrival;
	}

	public void setArrival(String arrival) {
		this.arrival = arrival;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public int getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(int departureTime) {
		this.departureTime = departureTime;
	}

	public int getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(int arrivalTime2) {
		this.arrivalTime = arrivalTime2;
	}

	public int getTotalTime() {
		return totalTime;
	}

	public void setTotalTime(int totalTime) {
		this.totalTime = totalTime;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}
	
	
}
