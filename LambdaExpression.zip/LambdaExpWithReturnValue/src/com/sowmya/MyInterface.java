package com.sowmya;

@FunctionalInterface
public interface MyInterface {
	boolean test(int n1,int n2);
}
