package com.sowmya.hashMap;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class HashMapIllustration {

	public static void main(String[] args) {
		
		//declaring HashMap
		HashMap<Integer,String> hashMap=new HashMap<Integer,String>();
		
		//Adding objects to HashMap
		hashMap.put(10, "Onkar");
		hashMap.put(11, "Sachin");
		hashMap.put(12, "Onkar");
		hashMap.put(14, "Amit");
		hashMap.put(13, "Rahul");
		
		System.out.println("******************************************");
		
		//Retrieving specific entry from hashMap using keys
		System.out.println("Value at key 10: "+hashMap.get(10));
		
		System.out.println("******************************************");
		
		System.out.println("Keys in HashMap are:");
		//Retrieving all keys 
		for(Integer key:hashMap.keySet()) {
			System.out.println(key);
		}
		
		System.out.println("******************************************");
		
		System.out.println("Values in HashMap are");
		//Retrieving all values 
		for(String values:hashMap.values()) {
			System.out.println(values);
		}
		
		System.out.println("******************************************");
		
		//Displaying size
		System.out.println("Size of HashMap: "+hashMap.size());
		
		System.out.println("******************************************");
		
		//Clear the HashMap once in all
		hashMap.clear();
		System.out.println("Size after clearing: "+ hashMap.size());
		
		//Adding values again
		hashMap.put(10, "Onkar");
		hashMap.put(11, "Sachin");
		hashMap.put(12, "Onkar");
		hashMap.put(14, "Amit");
		hashMap.put(13, "Rahul");
		
		System.out.println("******************************************");
		System.out.println("Keys and Values Entered are: ");
		//Displaying both Key and value
		for(Entry<Integer,String> index:hashMap.entrySet()) {
			System.out.println(index);
		}
		

		//Displaying Unsorted Map
        System.out.println("Unsort Map......");
        printMap(hashMap);
		
		System.out.println("\nSorted Map......By Key");
        Map<Integer, String> treeMap = new TreeMap<Integer, String>(hashMap);
        printMap(treeMap);

    }

    //pretty print a map
    public static <K, V> void printMap(Map<K, V> map) {
        for (Map.Entry<K, V> entry : map.entrySet()) {
            System.out.println("Key : " + entry.getKey() 
				+ " Value : " + entry.getValue());
        }
	}
}
