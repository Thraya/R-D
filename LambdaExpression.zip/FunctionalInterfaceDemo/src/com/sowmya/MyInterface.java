package com.sowmya;

@FunctionalInterface
public interface MyInterface {
	public abstract void method1();
	public abstract int hashCode();
	public boolean equals(Object obj);
}
