package com.sowmya;

@FunctionalInterface
public interface Interface2 extends MyInterface1 {

}
