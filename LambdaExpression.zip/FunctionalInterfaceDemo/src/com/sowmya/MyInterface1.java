package com.sowmya;

@FunctionalInterface
public interface MyInterface1 {
	void method1();
}
