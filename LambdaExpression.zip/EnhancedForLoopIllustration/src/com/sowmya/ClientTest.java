package com.sowmya;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ClientTest {

	public static void main(String[] args) {
		List<Student> stuList=new ArrayList<>();
		stuList.add(new Student("Sean",45));
		stuList.add(new Student("Sean1",40));
		stuList.add(new Student("Sean2",42));
		
		//internal iteration
		stuList.forEach(System.out::println);
		
		System.out.println("--------------------------");
		
		//external iteration
		for(Student student:stuList) {
			System.out.println(student);
		}
		
		System.out.println("--------------------------");
		
		//iteration using iterator
		Iterator<Student> iterator =stuList.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
}
