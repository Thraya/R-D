package com.sowmya.model;

public class MyThread implements Runnable{

	@Override
	public void run() {
		System.out.println("My task is executing");
	}

}
