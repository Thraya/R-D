package com.sowmya.client;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.sowmya.model.Employee;

public class ClientTest {

	public static void main(String[] args) {
		
		Map<Integer,Employee> map=new HashMap<>();
		map.put(1,new Employee("Sean","sean.m@gmail.com",19000.00));
		map.put(2,new Employee("Sowmya","sowmya.m@gmail.com",17000.00));
		map.put(3,new Employee("Gagana","gagana.m@gmail.com",25000.00));
		
		Set<Entry<Integer,Employee>> entrySet=map.entrySet();
		for(Entry<Integer,Employee> entry:entrySet) {
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
		}
		System.out.println("------------------");
		Set<Integer> keySet=map.keySet();
		for(Integer key:keySet) {
			System.out.println(key);
			System.out.println(map.get(key));
		}
		
		System.out.println("------------------");
		map.forEach((k,v)->System.out.println(k+"\t"+v));
	}

}
