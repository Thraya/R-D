package com.sowmya;

@FunctionalInterface
public interface MyInterface1 {
	
	public abstract void method1();
}
