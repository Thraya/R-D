package com.sowmya;

@FunctionalInterface
public interface MyInterface2 {
	void method2(String name);
}
