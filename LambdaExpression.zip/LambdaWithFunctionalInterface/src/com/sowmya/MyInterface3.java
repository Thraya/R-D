package com.sowmya;

public interface MyInterface3 {
	void method3(String name,int age);
}
