package com.sowmya.overridingAndPolymorphism;

/*
 * Overriding and Polymorphism
 */
public class TestClass {
	public static void main(String[] args) {
		Animal a=new Animal(); //early-binding or static binding
		Animal b=new Dog();//late-binding or dynamic binding
		a.run();
		b.run();
	}

}
