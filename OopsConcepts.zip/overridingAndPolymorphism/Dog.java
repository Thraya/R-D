package com.sowmya.overridingAndPolymorphism;

public class Dog extends Animal {
	
	//Overriding run method of class Animal
	
	@Override
	public void run() {
		System.out.println("Dog walks");
	
	}
}
