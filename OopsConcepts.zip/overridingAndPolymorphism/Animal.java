package com.sowmya.overridingAndPolymorphism;

public class Animal {
	public void run() {
		System.out.println("Animals run");
	}

}
