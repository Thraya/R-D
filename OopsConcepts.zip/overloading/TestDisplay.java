package com.sowmya.overloading;
/*
 * overloading
 */
public class TestDisplay {

	public static void main(String[] ags) {
		Display a=new Display();
		a.display1('a');
		a.display1('a', 10);
	}
}
