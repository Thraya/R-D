package com.sowmya.overloading;


public class Display {
	//overloading same method name but different parameters
	public void display1(char character) {
		System.out.println(character);
	}
	
	public void display1(char character, int number) {
		System.out.println(character + " "+number);
	}

}
