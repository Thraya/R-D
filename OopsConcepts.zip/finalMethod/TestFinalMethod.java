package com.sowmya.finalMethod;
/*
 * final method overriding and final class
 */

public /*final*/ class TestFinalMethod {
	
	/*final*/ void  displayFinal() {
		System.out.println("It works!!!!");
	}

}

class Test extends TestFinalMethod {
	void displayFinal() {
		System.out.println("OOPssss!!!");
	}
}
