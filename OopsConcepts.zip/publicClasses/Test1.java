package com.sowmya.publicClasses;
/*
 * Same source file with 2 public classes
 */
public class Test1 {
	
	public static void main(String[] args) {
		System.out.println("Hello");
	}

}

class Test2 {
	 public static void main(String[] args) {
			System.out.println("Hai");
		}
}
