package com.sowmya.staticBlock;
/*
 * Calling main method from static block
 */
public class TestProgram {
	
	static{
		TestProgram t=new TestProgram();
		t.main();
		System.out.println("Calling main from static block");
		TestProgram.main(null);
	}
	
	public void main() { 
		System.out.println("Hello");
	}
	
	public static void main(String[] args) {
		System.out.println("Hai");
	}
}
