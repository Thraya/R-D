package com.sowmya.abstraction;
/*
 * Abstraction in java
 */
public class Test {
	public static void main(String[] args) {
		
		//Shape s1=new Shape(); => abstract class cannot be instantiated directly
		Shape shape1=new Circle("Red",3);
		Shape shape2=new Rectangle("Yellow",2,4);
		
		System.out.println(shape1.toString());
		System.out.println(shape2.toString());
	}

}
