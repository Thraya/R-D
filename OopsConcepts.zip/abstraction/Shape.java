package com.sowmya.abstraction;

//abstract class => This class contains more than 1 abstract method hence the class is made abstract
abstract class Shape {
	String color;
	
	// Abstract methods
	abstract double area();
	public abstract String toString();
	
	public Shape(String color) {
		super();
		System.out.println("Shape constructor called");
		this.color = color;
	}
	
	public String getColor() {
		return color;
	}
	
	
}
