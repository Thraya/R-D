package com.sowmya.abstraction;

public class Circle extends Shape {
	double radius;
	public Circle(String color,double radius) {
		super(color);
		System.out.println("Inside Circle Constructor");
		this.radius=radius;
	}

	//overriding methods of abstract class
	@Override 
	double area() {
		return Math.PI*radius*radius;
	}
	
	@Override
	public String toString() {
		return "Color of Circle: "+super.color+" Area: "+area();
	}
	

}
