package com.sowmya.abstraction;

public class Rectangle extends Shape {
	double length,width;
	
	public Rectangle(String color,double length,double width) {
		super(color);
		System.out.println("Inside Rectangle Constructor");
		this.length=length;
		this.width=width;
	}
	
	// Overriding abstract methods
	@Override
	double area() {
		return length*width;
	}

	@Override 
	public String toString() {
		return "Color of Rectangle: "+ super.color+" Area: "+ area();
	}

}
