package com.sowmya.inheritance;

public class Teacher {
	String designation = "Teacher";
	String collegeName = "abc";
	
	public void job() {
		System.out.println("Teaching");
	}

}
