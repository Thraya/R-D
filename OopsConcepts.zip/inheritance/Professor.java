package com.sowmya.inheritance;

/*
 * simple-Inheritance in java
 */
public class Professor extends Teacher{
	String subjectHandled="Java";
	
	public static void main(String[] args) {
		Professor p1=new Professor();
		System.out.println(p1.collegeName);
		System.out.println(p1.designation);
		System.out.println(p1.subjectHandled);
		p1.job();
	}
}
