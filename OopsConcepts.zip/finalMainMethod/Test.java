package com.sowmya.finalMainMethod;

/*
 *  Final method and protected class and static
 */
//protected class Test { 
public  class Test {
	public final static void main(String[] args) {
		System.out.println("Hello");
	}
}
