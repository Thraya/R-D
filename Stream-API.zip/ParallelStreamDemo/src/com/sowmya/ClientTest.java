package com.sowmya;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ClientTest {

	public static void main(String[] args) {
		List<Student> list=new ArrayList<>();
		
		list.add(new Student("AB",23));
		list.add(new Student("CD",16));
		list.add(new Student("EF",20));
		list.add(new Student("GH",14));
		list.add(new Student("IJ",15));
		
		Stream<Student> parallelStream=list.parallelStream();
		System.out.println("Student data sent for processing");
		parallelStream.forEach(s->doProcess(s));
	}

	private static void doProcess(Student s) {
		System.out.println(s);
	}

}
