package com.sowmya.flightOperation;

import java.util.LinkedList;

import com.sowmya.flight.FlightDetails;

public class FlightOperations {
	private LinkedList<FlightDetails> flightList;
	
	public FlightOperations() {
		flightList = new LinkedList<FlightDetails>();
	}
	
	//Adding Flight Details
	public void addNewFlight(FlightDetails flight) {
        flightList.add(flight);
    }
	
	// Displaying all flights
	public LinkedList<FlightDetails> getAllFlights() {
    	return flightList;
    }
	
	//Displaying Flight Details by ID
	public FlightDetails getFlightById(int flightId)
	{
		for(FlightDetails f1 : flightList) {
			if(f1.getFlightId() == flightId) {
				return f1;
			}
		}
		throw new RuntimeException("Flight Doesn't Exist");		
	}

	
	// Removing Flight Details only by specifying its number.
	public LinkedList<FlightDetails> removeFlightById(int flightId) {
		for(FlightDetails flight:flightList) {
			if(flight.getFlightId() == flightId) {
				flightList.remove(flight);
				return flightList;
					}
			}
		throw new RuntimeException("Flight does not exists");
	} 
 
	 //Updating Flight information by arrival time.
	public LinkedList<FlightDetails> updateFlightbyArrivalTime(int flightId, int arrivalTime) {
		for(FlightDetails flight:flightList) {
			if(flight.getFlightId()==flightId) {
				flight.setArrivalTime(arrivalTime);
			}
	}
		return flightList;
	} 
 

	 
	 //Updating Flight information by arrival time and departure time.
	public LinkedList<FlightDetails> updateFlightbyArrivalAndDeparture(int flightId, int arrivalTime,int departureTime) {
		for(FlightDetails flight:flightList) {
			if(flight.getFlightId()==flightId) {
				flight.setArrivalTime(arrivalTime);
				flight.setDepartureTime(departureTime);
				flight.setTotalTime(departureTime-arrivalTime);
			}
		}
		return flightList;
	} 
	
	 //Updating Flight information by departure time.
	public LinkedList<FlightDetails> updateFlightbyDepartureTime(int flightId, int departureTime) {
		for(FlightDetails flight:flightList) {
			if(flight.getFlightId()==flightId) {
				flight.setDepartureTime(departureTime);
			}
	}
		return flightList;
	} 
 
	 //Updating Flight information by destination.
	public LinkedList<FlightDetails> updateFlightbyDestination(int flightId, String destination) {
		for(FlightDetails flight:flightList) {
			if(flight.getFlightId()==flightId) {
				flight.setDeparture(destination);
			}
	}
		return flightList;
	} 
	 
	
	public LinkedList<FlightDetails> filterBySrcDest(String source, String destination){
		for(FlightDetails flight:flightList) {
			if(flight.getArrival() == source && flight.getDeparture() == destination) {
				searchList.add(flight);
			}
		}
		return searchList;
	}
	
					return flight1.getPrice() - flight2.getPrice();
			}
		});
		return searchList;
	} 
 

	 
	 public static void main(String[] args) {
	 	  FlightOperations list = new FlightOperations();
	 	  list.addNewFlight(new FlightDetails(100,"Air India","Bangalore", "Chennai", 9, 11, 2,4000));
	 	  list.addNewFlight(new FlightDetails(101,"Spice jet","Hyderabad", "Bangalore", 13, 16, 3,5000));
	 	  list.addNewFlight(new FlightDetails(103,"Jet Airways","Delhi", "Mumbai", 16, 20, 4,6000));
	 	  list.addNewFlight(new FlightDetails(104,"Indigo","Mumbai", "Kolkata", 19, 21, 3,7000));
	 	 
	 	  // Displaying all flights 
	 	 for(FlightDetails f1:list.getAllFlights()) {
	 		   System.out.println(f1);
	 	   } 
	 	 System.out.println("========================================");
	 	
	     //Display Flight by ID
	 	 System.out.println(list.getFlightById(103));
	 	 
	 	 System.out.println("========================================");
	 	 
	 	 //Remove Flight by Id
	 	 System.out.println(list.removeFlightById(104));
	 	 
	 	 // Update Flight By Arrival time
	 	System.out.println("========================================");
	 	for(FlightDetails f1:list.updateFlightbyArrivalTime(100, 16)) {
	 		   System.out.println(f1);
	 	   } 
	 	
	 	 // Update Flight By Depaturetime
	 	System.out.println("========================================");
	 	for(FlightDetails f1:list.updateFlightbyDepartureTime(101,14)){
	 		   System.out.println(f1);
	 	   } 
	 // Update Flight By Depaturetime
	 	 	System.out.println("========================================");
	 	 	for(FlightDetails f1:list.updateFlightbyArrivalAndDeparture(103, 11, 15)) {
	 	 		   System.out.println(f1);
	 	  } 
	 	 
    }
}